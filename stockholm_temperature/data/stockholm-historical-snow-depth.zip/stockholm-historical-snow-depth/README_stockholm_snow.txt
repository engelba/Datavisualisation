README_stockholm_snow.txt

This file describes the contents of a dataset with files containing the maximum observed snow depth at Stockholm Old Astronomical Observatory 
(59.3417N, 18.0549E) each winter from 1904/05 to 2018/19.

The dataset is available at https://bolin.su.se/data/stockholm-historical-snow-depth

The data are availabe in two file formats: 
1. plain text files (.txt) with fixed width on each row between data columns
2. tab-separated-value files (.tsv)

Contact person:

Anders Moberg
Department of Physical Geography
Stockholm University
SE-10691 Stockholm, Sweden
anders.moberg@natgeo.su.se

2019-07-30

Data for 1904-1950 provided personally by staff at SMHI.

Data for 1951-onwards obtained using data from SMHI �ppna Data,
http://opendata-download-metobs.smhi.se/explore/#


--- File list ---

README_stockholm_snow.txt ( = this file )
stockholm_snow_depth_2018.png
/txt/stockholm_snow_2018.txt
/tsv/stockholm_snow_2018.tsv

Each data file has one year per row and three columns.

column 1 : year when December falls
column 2 : max snow depth (in cm) in December
column 3 : max snow depth (in cm) during December-April

A plot showing the data is available in the file stockholm_snow_depth_2018.png.




