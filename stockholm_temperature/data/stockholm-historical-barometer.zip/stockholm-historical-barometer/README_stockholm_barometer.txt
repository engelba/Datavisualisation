README_stockholm_barometer.txt

This file describes the contents of a dataset with files containing raw daily air pressure observation data (barometer readings in original units) from the Stockholm Old Astronomical Observatory (59.3417N, 18.0549E) 1756-2018.

The dataset is available at https://bolin.su.se/data/stockholm-historical-barometer

The data are availabe in two file formats: 
1. plain text files (.txt) with fixed width on each row between data columns
2. tab-separated value files (.tsv)

Contact person:

Anders Moberg
Department of Physical Geography
Stockholm University
SE-10691 Stockholm, Sweden
anders.moberg@natgeo.su.se

2019-08-01


Reference:

Moberg A, Bergstr�m H, Ruiz Krigsman J, Svanered O. 2002: Daily air temperature 
and pressure series for Stockholm (1756-1998). Climatic Change 53: 171-212

Project:

IMPROVE - Improved Understanding of Past Climatic Variability from Early Daily 
European Instrumental Sources. EU 4th Framework Programme. Contract
ENV4-CT97-0511. 1998-1999. Co-ordinator: Dario Camuffo, Consiglio Nazionale
delle Ricerche, Istituto di Scienze dell'Atmosfera e del Clima, Padova, Italy.
PI at Stockholm University: Anders Moberg

Original data sources:

1756-1858: Archive of the Royal Swedish Academy of Sciences
1859-now:  Swedish Meteorological and Hydrological Institute (SMHI)

Data for 1756-1838 were digitized at the SMHI. Data for 1839-1960 were digitized
within IMPROVE. Data for 1961-onwards were provided digitally by the SMHI. 

Data from 2013 onward were obtained by download from SMHI �ppna Data:
http://opendata-download-metobs.smhi.se/explore/#


--- File list ---

README_stockholm_barometer.txt ( = this file )
txt/stockholm_barometer_1756_1858.txt
txt/stockholm_barometer_1859_1861.txt
txt/stockholm_barometer_1862_1937.txt
txt/stockholm_barometer_1938_1960.txt
txt/stockholm_barometer_1961_2012.txt
txt/stockholm_barometer_2013_2018.txt
txt/stockholmA_barometer_2013_2018.txt
tsv/stockholm_barometer_1756_1858.tsv
tsv/stockholm_barometer_1859_1861.tsv
tsv/stockholm_barometer_1862_1937.tsv
tsv/stockholm_barometer_1938_1960.tsv
tsv/stockholm_barometer_1961_2012.tsv
tsv/stockholm_barometer_2013_2018.tsv
tsv/stockholmA_barometer_2013_2018.tsv

Each data file has one day per row and 6 to 12 columns.

The first three columns in all files are: 

Column 1: Year
Column 2: Month
Column 3: Date 

The content in the other columns differ between the files. See information
below. In all cases, however, data are provided for three daily observations
(morning, noon, evening). 

Missing observations are flagged with 'NaN'.

The observation hours are given by the dataset at:
https://bolin.su.se/data/stockholm-historical-obs-times

The barometer data have been quality controlled as described by Moberg et al. (2002), but are not subject to any homogenization or correction for known instrumental biases.
  

stockholm_barometer_1756_1858.*

	Observed barometer readings 1756-1858
	2 daily obs 1756-1784.05.31 (morning & evening)
	3 daily obs 1784.06.01-1861 (morning, noon, evening)
	Columns 4, 6, 8: barometer observations
	Unit: Swedish inches (29.69 mm)
	Columns 5, 7, 9: barometer temperature observations
	Unit: degC
	
stockholm_barometer_1859_1861.*

	Observed barometer readings 1859-1861
	3 daily obs
	Columns 4, 7, 10: barometer observations
	Unit: 0.1*Swedish inches (2.969 mm)
	Columns 5, 8, 11: thermometer observations
	Unit: degC
	Columns 6, 9, 12: air pressure reduced to 0 degC
	Unit: 0.1*Swedish inches (2.969 mm)

stockholm_barometer_1862_1937.*

	Air pressure from printed year-books 1862-1937
	3 daily obs
	Columns 4-6: air pressure
	Unit: mm Hg

stockholm_barometer_1938_1960.*

	Air pressure from printed year-books 1938-1960
	3 daily obs
	Columns 4-6: air pressure
	Unit: hPa

stockholm_barometer_1961_2012.*

	Air pressure provided digitally by SMHI
	3 daily obs
	Columns 4-6: air pressure
	Unit: hPa

stockholm_barometer_2013_2018.*

	Air pressure for the manual station, as downloaded from SMHI �ppna Data;
	http://opendata-download-metobs.smhi.se/explore/#
	3 daily obs
	Columns 4-6: air pressure
	Unit: hPa

stockholmA_barometer_2013_2018.*

	Air pressure for the automatic station, as downloaded from SMHI �ppna Data;
	http://opendata-download-metobs.smhi.se/explore/#
	3 daily obs
	Columns 4-6: air pressure
	Unit: hPa
